if cat /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh>/dev/null 2>&1;then
  if ! grep pidof /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh>/dev/null 2>&1;then
    echo Success
    echo '\nsh /storage/emulated/0/Android/data/moe.shizuku.privileged.api/stop.sh>/dev/null 2>&1\necho "kill $(pgrep -f moe.shizuku.privileged.api/start.sh|tr "\n" " ")">/storage/emulated/0/Android/data/moe.shizuku.privileged.api/stop.sh\nwhile :; do\n  sleep 1\n  if ! pidof shizuku_server; then\n    sh /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh\n  fi\ndone>/dev/null 2>&1'>>/storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh
    sh /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh>/dev/null 2>&1&
  else
    echo Already used
  fi
else
  echo Shizuku is not installed
fi