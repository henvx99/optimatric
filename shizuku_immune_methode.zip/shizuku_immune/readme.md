buat yang shizukunya mati otomatis atau mati sendiri saya
sarankan menggunakan methode ini agar aman dan enak

# Pasang :
sh /sdcard/shizuku_immune/shizuku.sh

# Copot :
rm -rf /sdcard/Android/data/moe.shizuku.privileged.api

# Copy folder shizuku_immune ke sdcard lalu masukin command pasang/copot.
# Credit By @HoyoSlave